import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom'; 
import './Transaction.css'; 

const Transaction = () => {
  const [transactions, setTransactions] = useState([]);
  const [accounts, setAccounts] = useState({});
  const [formData, setFormData] = useState({
    accountNumber: '',
    amount: '',
    type: 'Deposit',
    transferToAccount: ''
  });
  const [errorMessage, setErrorMessage] = useState(''); // Error handling for invalid transactions

  const navigate = useNavigate(); // Initialize useNavigate for redirection
  const location = useLocation(); // To access state from navigation

  useEffect(() => {
    // Get initial account data from location state or set default values
    const initialAccounts = location.state?.accounts || {
      100: 1000, // Default balance
      102: 500   // Default balance
    };
    setAccounts(initialAccounts);
  }, [location.state]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { accountNumber, amount, type, transferToAccount } = formData;
    const parsedAmount = parseFloat(amount);

    // Error handling for invalid inputs
    if (!accounts[accountNumber]) {
      setErrorMessage('Account number does not exist.');
      return;
    }
    if (type === 'eTransfer' && !accounts[transferToAccount]) {
      setErrorMessage('Transfer to account does not exist.');
      return;
    }
    if (parsedAmount <= 0) {
      setErrorMessage('Amount should be a positive number.');
      return;
    }
    if (type === 'Withdrawal' && (accounts[accountNumber] || 0) < parsedAmount) {
      setErrorMessage('Insufficient funds for withdrawal.');
      return;
    }
    if (type === 'eTransfer' && (accounts[accountNumber] || 0) < parsedAmount) {
      setErrorMessage('Insufficient funds for e-Transfer.');
      return;
    }
    setErrorMessage('');

    // Perform the transaction
    if (type === 'Deposit') {
      setAccounts({
        ...accounts,
        [accountNumber]: (accounts[accountNumber] || 0) + parsedAmount,
      });
    } else if (type === 'Withdrawal') {
      setAccounts({
        ...accounts,
        [accountNumber]: accounts[accountNumber] - parsedAmount,
      });
    } else if (type === 'eTransfer') {
      setAccounts({
        ...accounts,
        [accountNumber]: accounts[accountNumber] - parsedAmount,
        [transferToAccount]: (accounts[transferToAccount] || 0) + parsedAmount,
      });
    }

    // Record the transaction
    setTransactions([ ...transactions, { ...formData, date: new Date().toLocaleDateString() } ]);
    setFormData({ ...formData, accountNumber: '', amount: '', transferToAccount: '' }); // Reset form
  };

  const handleLogout = () => {
    // Log out the user and redirect to the login page
    navigate('/login'); // Redirect to the login page
  };

  const handleCancel = () => {
    // Clear input fields but retain the transaction type
    setFormData(prevData => ({
      ...prevData,
      accountNumber: '',
      amount: '',
      transferToAccount: prevData.type === 'eTransfer' ? '' : prevData.transferToAccount
    }));
    setErrorMessage(''); // Clear any error messages
  };

  const renderForm = () => {
    return (
      <form onSubmit={handleSubmit} className="transaction-form">
        <div className="form-group">
          <label htmlFor="accountNumber">Account Number</label>
          <input
            type="text"
            className="form-control"
            id="accountNumber"
            name="accountNumber"
            value={formData.accountNumber}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amount">Amount</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            required
            min="0"
            step="any"
          />
        </div>
        {formData.type === 'eTransfer' && (
          <div className="form-group">
            <label htmlFor="transferToAccount">To</label>
            <input
              type="text"
              className="form-control"
              id="transferToAccount"
              name="transferToAccount"
              value={formData.transferToAccount}
              onChange={handleChange}
              required
            />
          </div>
        )}
        {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
        <div className="form-buttons mt-3">
          <div className="button-group">
            <button type="submit" className="btn-custom btn-lg">
              {formData.type}
            </button>
            <button type="button" className="btn-custom btn-lg" onClick={handleCancel}>
              Cancel
            </button>
          </div>
        </div>
      </form>
    );
  };

  return (
    <div className="container py-5">
      <h2 className="text-center">Transaction Management</h2>

      <div className="transaction-type-selector mb-4 text-center">
        <h3>Select Transaction Type</h3>
        <div className="btn-group">
          <button
            className={`btn ${formData.type === 'Deposit' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFormData({ ...formData, type: 'Deposit' })}
          >
            Deposit
          </button>
          <button
            className={`btn ${formData.type === 'Withdrawal' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFormData({ ...formData, type: 'Withdrawal' })}
          >
            Withdraw
          </button>
          <button
            className={`btn ${formData.type === 'eTransfer' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFormData({ ...formData, type: 'eTransfer' })}
          >
            Interac e-Transfer
          </button>
        </div>
      </div>

      {/* Render Form Based on Transaction Type */}
      {renderForm()}

      {/* Transaction History */}
      <div className="transaction-history mt-4">
        <h3 className="text-center">Transaction History</h3>
        <table className="table table-striped transaction-table mt-3">
          <thead>
            <tr>
              <th>Date</th>
              <th>Account Number</th>
              <th>Type</th>
              <th>Amount</th>
              <th>Transfer To Account</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              <tr key={index}>
                <td>{transaction.date}</td>
                <td>{transaction.accountNumber}</td>
                <td>{transaction.type}</td>
                <td>${transaction.amount}</td>
                <td>{transaction.type === 'eTransfer' ? transaction.transferToAccount : 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Display Account Balances */}
      <div className="account-balances mt-4">
        <h3 className="text-center">Account Balances</h3>
        <ul className="list-group">
          {Object.keys(accounts).map((account) => (
            <li className="list-group-item" key={account}>
              Account {account}: ${accounts[account]}
            </li>
          ))}
        </ul>
      </div>

      {/* Logout Button */}
      <div className="text-center mt-4">
        <button className="btn btn-danger btn-lg" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </div>
  );
};

export default Transaction;
