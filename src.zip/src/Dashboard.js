// src/Dashboard.js
import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  return (
    <div className="container py-5">
      
      <div className="row mt-4">
        <div className="col-md-4">
          <h3>Manage Transactions</h3>
          <Link
            to="/transactions"
            className="btn"
            style={{
              backgroundColor: '#065c70',
              color: '#fff',
              borderColor: '#065c70', 
            }}
          >
            Go to Transactions
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
